<?php

set_include_path(__DIR__);
chdir(__DIR__);

require 'Model/StockPrice.php';

// Add the path of each other model here
